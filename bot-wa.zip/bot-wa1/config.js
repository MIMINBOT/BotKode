module.exports = {
	chrome_path: "C:/Program Files/Google/Chrome/Application/chrome.exe",
// for linux use /usr/bin/google-chrome-stable

	ffmpeg_path: "PATH_FFMPEG"
}
