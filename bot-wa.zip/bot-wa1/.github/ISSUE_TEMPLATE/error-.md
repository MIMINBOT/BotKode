---
name: 'Error '
about: Describe this issue template's purpose here.
title: ''
labels: bug
assignees: ''

---

Describe how bot is not working on your system
